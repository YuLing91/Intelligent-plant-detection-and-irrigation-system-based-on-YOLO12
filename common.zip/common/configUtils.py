import os

import yaml


def getConfig(configFilePath):
    with open(os.path.join(configFilePath)) as f:
        cfgDict = yaml.safe_load(f)
    return Dict2Obj(cfgDict)


class Dict2Obj(dict):
    """
    将字典转化为Obj以便于使用Obj.str调用参数而不用dict['str']
    """
    def __init__(self, *args, **kwargs):
        super(Dict2Obj, self).__init__(*args, **kwargs)

    def __getattr__(self, key):
        value = self[key]
        if isinstance(value, dict):
            value = Dict2Obj(value)
        return value