import torch
import torch.nn as nn
from torchvision.ops import RoIPool

from nets.classifier import VGG16RoIHead
from nets.resnet50 import resnet50
# from nets.resnet51 import resnet50
from nets.rpn import RegionProposalNetwork
from nets.vgg16 import decom_vgg16


class FasterRCNNBackbone(nn.Module):
    def __init__(self, num_classes,
                 mode="testing",
                 feat_stride=16,
                 anchor_scales=[8, 16, 32],
                 ratios=[0.5, 1, 2],
                 backbone='vgg',
                 pretrained=False):
        super().__init__()
        self.feat_stride = feat_stride
        # ---------------------------------#
        #   一共存在两个主干
        #   vgg和resnet50
        # ---------------------------------#
        if backbone == 'vgg':
            self.extractor, classifier = decom_vgg16(pretrained)
            # ---------------------------------#
            #   构建建议框网络
            # ---------------------------------#
            self.rpn = RegionProposalNetwork(
                512, 512,
                ratios=ratios,
                anchor_scales=anchor_scales,
                feat_stride=self.feat_stride,
                mode=mode
            )
            # ---------------------------------#
            #   构建分类器网络
            # ---------------------------------#
            self.head = VGG16RoIHead(
                n_class=num_classes + 1,
                roi_size=7,
                spatial_scale=1,
                classifier=classifier
            )
        elif backbone == 'resnet50':
            self.extractor, classifier = resnet50(pretrained)
            # ---------------------------------#
            #   构建classifier网络
            # ---------------------------------#
            self.rpn = RegionProposalNetwork(
                1024, 512,
                ratios=ratios,
                anchor_scales=anchor_scales,
                feat_stride=self.feat_stride,
                mode=mode
            )

            self.head = Resnet50RoIHead(
                n_class=num_classes + 1,
                roi_size=14,
                spatial_scale=1,
                classifier=classifier
            )

    def forward(self, x, scale=1.):
        # ---------------------------------#
        #   计算输入图片的大小
        # ---------------------------------#
        img_size = x.shape[2:]
        # ---------------------------------#
        #   利用主干网络提取特征
        # ---------------------------------#
        base_feature = self.extractor.forward(x)

        # ---------------------------------#
        #   获得建议框
        # ---------------------------------#
        _, _, rois, roi_indices, _ = self.rpn.forward(base_feature, img_size, scale)
        # ---------------------------------------#
        #   获得classifier的分类结果和回归结果
        # ---------------------------------------#
        pools, box = self.head(base_feature, rois, roi_indices, img_size)
        # return roi_cls_locs, roi_scores, rois, roi_indices
        return pools, box

    def freeze_bn(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                m.eval()


class Resnet50RoIHead(nn.Module):
    def __init__(self, n_class, roi_size, spatial_scale, classifier):
        super().__init__()
        self.roi = RoIPool((roi_size, roi_size), spatial_scale)

    def forward(self, x, rois, roi_indices, img_size):
        n, _, _, _ = x.shape

        # if x.is_cuda:
        #     roi_indices = roi_indices.cuda()
        #     rois = rois.cuda()
        # print(x.device)

        roi_indices = roi_indices.to(x.device)
        rois = rois.to(x.device)

        rois_feature_map = torch.zeros_like(rois)
        rois_feature_map[:, [0, 2]] = rois[:, [0, 2]] / img_size[1] * x.size()[3]
        rois_feature_map[:, [1, 3]] = rois[:, [1, 3]] / img_size[0] * x.size()[2]

        indices_and_rois = torch.cat([roi_indices[:, None], rois_feature_map], dim=1)
        # -----------------------------------#
        #   利用建议框对公用特征层进行截取
        # -----------------------------------#
        pool = self.roi(x, indices_and_rois)
        _, c, h, w = pool.size()
        return pool.view(n, -1, c, h, w), rois_feature_map.view(n, -1, 4)
