from functools import partial

import torch
from torch import nn

from DRL.net.utils import PatchEmbed, PosEmbed, Block


class PSDNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.classNumb = 5
        self.input_chanel = 1024
        norm_layer = partial(nn.LayerNorm, eps=1e-6)
        self.norm = norm_layer(300)
        self.patchEmbed = PatchEmbed()
        self.posEmbed = PosEmbed(cls=5, pro=1)
        self.cls_token = nn.Parameter(torch.ones(1, 1, 300))
        self.weight_token = nn.Parameter(torch.ones(1, 1, 300))
        self.preCNN = nn.Sequential(
            nn.Conv2d(in_channels=self.input_chanel, out_channels=512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.Conv2d(in_channels=512, out_channels=256, kernel_size=3, padding=1, stride=2),
            nn.BatchNorm2d(256),
            nn.Conv2d(in_channels=256, out_channels=128, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(128),
            nn.Conv2d(in_channels=128, out_channels=64, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(64),
            nn.Conv2d(in_channels=64, out_channels=32, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(32),
            nn.Conv2d(in_channels=32, out_channels=16, kernel_size=3, padding=1, stride=1),
            nn.BatchNorm2d(16),
        )

        self.block = nn.Sequential(*[
            Block(dim=300, num_heads=10)
            for i in range(4)
        ])

    def forward(self, pool, box):
        batch, num, c, h, w = pool.size()
        x = pool.view(-1, c, h, w)
        box = box.view(batch, num, -1)
        x = self.preCNN(x)
        # x = x.view(batch, 300, 16, 7, 7)
        x = self.patchEmbed(x).view(batch, 300, -1).permute(0, 2, 1).contiguous()

        cls_token = self.cls_token.expand(x.shape[0], self.classNumb, -1)
        weight_token = self.weight_token.expand(x.shape[0], -1, -1)
        # x -> b, 790, 300
        x = torch.cat((cls_token, weight_token, x), dim=1)

        pos = self.posEmbed(box).permute(0, 2, 1).contiguous()
        x += pos
        x = self.block(x)
        x = self.norm(x)

        cls = x[:, 0:5]
        pro = x[:, 5:6]

        res = torch.softmax(cls, dim=1) * pro
        res = torch.sum(res, dim=-1)

        return res
