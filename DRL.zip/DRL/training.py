import math
import os.path

import torch
from torch import optim
from torch.utils.data import DataLoader
import torch.optim.lr_scheduler as lr_scheduler

from torchvision import datasets
from torchvision.transforms import transforms
from tqdm import tqdm

from DRL.net.PSDNet import PSDNet
from nets.frcnnBackbone import FasterRCNNBackbone


def train(cfg):
    if not os.path.exists(cfg.path.save):
        os.mkdir(cfg.path.save)

    # FRCNN model
    preNet = FasterRCNNBackbone(
        cfg.model.frcnn.num_classes,
        anchor_scales=cfg.model.frcnn.anchors_size,
        backbone=cfg.model.frcnn.backbone
    ).to(cfg.train.device)
    frcnn_weight = torch.load(cfg.model.frcnn.model_path, map_location=cfg.train.device)
    model_dict = preNet.state_dict()
    state_dict = {k: v for k, v in frcnn_weight.items() if k in model_dict.keys()}
    model_dict.update(state_dict)
    preNet.load_state_dict(model_dict)

    # judge model
    net = PSDNet(

    )
    net.train()

    training_dataSet = datasets.ImageFolder(
        cfg.dataSet.path,
        transforms.Compose([
            transforms.Resize(cfg.train.shape),
            transforms.ToTensor()])
    )

    trainingDataLoader = DataLoader(training_dataSet, batch_size=cfg.train.batch_size)

    optimizer = optim.SGD(net.parameters(), lr=cfg.train.lr, momentum=0.9, weight_decay=5E-5)

    epochs = cfg.train.epoch

    lf = lambda x: ((1 + math.cos(x * math.pi / epochs)) / 2) * (1 - cfg.train.lrf) + cfg.train.lrf  # cosine
    scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lf)
    loss_function = torch.nn.CrossEntropyLoss()
    # print(len(trainingDataLoader))
    for epoch in range(epochs):
        with tqdm(total=len(trainingDataLoader), desc=f'Epoch {epoch + 1}/{epochs}') as pbar:
            accu_num = 0
            accu_loss = 0
            for batch in trainingDataLoader:
                img, target = batch
                img = img.to(cfg.train.device)
                target = target.to(cfg.train.device)
                with torch.no_grad():
                    pool, box = preNet(img)
                output = net(pool, box)

                pred_classes = torch.max(output, dim=1)[1]
                accu_num += torch.eq(pred_classes, target.to(cfg.train.device)).sum()
                loss = loss_function(output, target.to(cfg.train.device))
                loss.backward()
                accu_loss += loss.detach()

                optimizer.step()
                optimizer.zero_grad()
                pbar.update(1)
        scheduler.step()
        print('acc number:', accu_num)
        print('acc loss:', accu_loss)
        torch.save(net.state_dict(), cfg.path.save + "/model-{}.pth".format(epoch))


