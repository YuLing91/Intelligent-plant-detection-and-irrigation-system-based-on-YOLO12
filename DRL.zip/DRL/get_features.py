def getFeature(cfg):
    pass